# Origin / ArcGAF：归档读取与解码

算法资料，未执行验证；不改变随包支持声明。API、边界和外部参数见 [读取约定](../../reading.md)。

## 格式入口

| 标识/API | 扩展名 | 文件头候选（u32 小端字节） | 来源写入声明 |
|---|---|---|---|
| `GAF/ORIGIN` / `GameRes.Formats.Origin.GafOpener` | `` | 无固定签名或来源表达式未解析 | `False` |

## 字段与结构读取

以下保留源码的偏移表达式。`entry.Offset` 为最终成员跨度；`base_offset + offset` 等表达式中的基址以算法摘录为准。表中重复读取可属于不同版本或分支，不能拼成一个假定的统一头部。

| 算法位置 | 读取表达式 |
|---|---|
| `GafOpener.TryOpen` | `int count = file.View.ReadInt32 (8);` |
| `GafOpener.TryOpen` | `uint width  = file.View.ReadUInt32 (0);` |
| `GafOpener.TryOpen` | `uint height = file.View.ReadUInt32 (4);` |
| `GafOpener.TryOpen` | `unpacked += file.View.ReadByte (offset+1);` |

## 读取、解密与解压步骤

按所属类和入口选择分支，固定常量只用于引用它们的方言。外部方案库需要显式参数；摘录省略 writer、GUI 和资源注册。

### GameRes.Formats.Origin.GafArchive

继承/接口：`ArcFile`。

#### 状态与常量

```csharp
public readonly ImageMetaData  Info ;
```

#### GafArchive

```csharp
public GafArchive (ArcView arc, ArchiveFormat impl, ICollection<Entry> dir, ImageMetaData info)
    : base (arc, impl, dir) {
    Info = info;
}
```

### GameRes.Formats.Origin.GafOpener

继承/接口：`ArchiveFormat`。

#### GafOpener

```csharp
public GafOpener () {
    Extensions = new string[] { "" };
}
```

#### TryOpen

```csharp
public override ArcFile TryOpen (ArcView file) {
    if (!VFS.IsPathEqualsToFileName (file.Name, "gaf"))
        return null;
    int count = file.View.ReadInt32 (8);
    if (!IsSaneCount (count))
        return null;
    uint width  = file.View.ReadUInt32 (0);
    uint height = file.View.ReadUInt32 (4);
    if (width == 0 || width > 0x4000 || height == 0 || height > 0x4000)
        return null;
    uint offset = 0xC;
    var base_name = Path.GetFileNameWithoutExtension (file.Name);
    var dir = new List<Entry> (count);
    uint image_size = width * height;
    for (int i = 0; i < count; ++i)
    {
        var entry = new Entry {
            Name = string.Format ("{0}#{1:D4}", base_name, i),
            Type = "image",
            Offset = offset,
        };
        if (i + 1 < count)
        {
            uint unpacked = 0;
            while (unpacked < image_size && offset < file.MaxOffset)
            {
                unpacked += file.View.ReadByte (offset+1);
                offset += 2;
            }
        }
        else
        {
            offset = (uint)file.MaxOffset;
        }
        entry.Size = (uint)(offset - entry.Offset);
        dir.Add (entry);
    }
    var info = new ImageMetaData { Width = width, Height = height, BPP = 8 };
    return new GafArchive (file, this, dir, info);
}
```

## 配套算法与外部条件

本源文件没有解析到其他专用算法依赖；标准压缩、框架 API 和显式游戏参数的约定仍见读取约定。

## 出处与许可

来源文件标识 `ArcFormats/Origin/ArcGAF.cs`；版本、UTF-8 解码内容哈希与版权/许可通知见 [出处清单](../../../../provenance/garbro-archive-excerpts.json)和 [原通知](../../../../provenance/garbro-archive-notices.md)。路径是出处，不是使用时需要访问的外部文件。
