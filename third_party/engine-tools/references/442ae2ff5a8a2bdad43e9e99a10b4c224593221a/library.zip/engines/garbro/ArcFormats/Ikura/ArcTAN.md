# Ikura / ArcTAN：归档读取与解码

算法资料，未执行验证；不改变随包支持声明。API、边界和外部参数见 [读取约定](../../reading.md)。

## 格式入口

| 标识/API | 扩展名 | 文件头候选（u32 小端字节） | 来源写入声明 |
|---|---|---|---|
| `TAN/DO` / `GameRes.Formats.Ikura.TanOpener` | `tan` | 无固定签名或来源表达式未解析 | `False` |

## 字段与结构读取

以下保留源码的偏移表达式。`entry.Offset` 为最终成员跨度；`base_offset + offset` 等表达式中的基址以算法摘录为准。表中重复读取可属于不同版本或分支，不能拼成一个假定的统一头部。

| 算法位置 | 读取表达式 |
|---|---|
| `TanOpener.TryOpen` | `int count = file.View.ReadInt16 (0);` |
| `TanOpener.TryOpen` | `Width  = file.View.ReadUInt16 (index_pos),` |
| `TanOpener.TryOpen` | `Height = file.View.ReadUInt16 (index_pos+2),` |
| `TanOpener.TryOpen` | `count = file.View.ReadInt16 (index_pos);` |
| `TanOpener.TryOpen` | `Offset = base_offset + file.View.ReadUInt32 (index_pos),` |

## 读取、解密与解压步骤

按所属类和入口选择分支，固定常量只用于引用它们的方言。外部方案库需要显式参数；摘录省略 writer、GUI 和资源注册。

### GameRes.Formats.Ikura.TanEntry

继承/接口：`Entry`。

#### 状态与常量

```csharp
public int  Index ;
```

### GameRes.Formats.Ikura.TanArchive

继承/接口：`ArcFile`。

#### 状态与常量

```csharp
public readonly TanMetaData Info ;
```

#### TanArchive

```csharp
public TanArchive (ArcView arc, ArchiveFormat impl, ICollection<Entry> dir, TanMetaData info)
    : base (arc, impl, dir) {
    Info = info;
}
```

### GameRes.Formats.Ikura.TanOpener

继承/接口：`ArchiveFormat`。

#### TryOpen

```csharp
public override ArcFile TryOpen (ArcView file) {
    if (!file.Name.HasExtension (".tan"))
        return null;
    int count = file.View.ReadInt16 (0);
    if (!IsSaneCount (count))
        return null;
    uint index_pos = 2 + (uint)count * 4;
    var info = new TanMetaData {
        Width  = file.View.ReadUInt16 (index_pos),
        Height = file.View.ReadUInt16 (index_pos+2),
        BPP    = 8,
        DataOffset = index_pos + 4,
    };
    index_pos += 0x404;
    count = file.View.ReadInt16 (index_pos);
    if (!IsSaneCount (count))
        return null;
    index_pos += 2;

    var base_name = Path.GetFileNameWithoutExtension (file.Name);
    var base_offset = index_pos + 4 * count;
    var dir = new List<Entry> (count);
    for (int i = 0; i < count; ++i)
    {
        var entry = new TanEntry {
            Name = string.Format ("{0}#{1:D2}", base_name, i),
            Type = "image",
            Offset = base_offset + file.View.ReadUInt32 (index_pos),
            Index = i,
        };
        dir.Add (entry);
        index_pos += 4;
    }
    for (int i = 1; i < count; ++i)
    {
        dir[i-1].Size = (uint)(dir[i].Offset - dir[i-1].Offset);
        if (!dir[i-1].CheckPlacement (file.MaxOffset))
            return null;
    }
    dir[dir.Count-1].Size = (uint)(file.MaxOffset - dir[dir.Count-1].Offset);
    return new TanArchive (file, this, dir, info);
}
```

## 配套算法与外部条件

- [ArcFormats/Ikura/ImageTAN.cs](ImageTAN.md)：本页引用的随包算法资料。

## 出处与许可

来源文件标识 `ArcFormats/Ikura/ArcTAN.cs`；版本、UTF-8 解码内容哈希与版权/许可通知见 [出处清单](../../../../provenance/garbro-archive-excerpts.json)和 [原通知](../../../../provenance/garbro-archive-notices.md)。路径是出处，不是使用时需要访问的外部文件。
