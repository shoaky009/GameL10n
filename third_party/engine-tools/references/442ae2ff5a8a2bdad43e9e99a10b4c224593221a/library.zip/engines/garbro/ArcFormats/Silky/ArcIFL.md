# Silky / ArcIFL：归档读取与解码

算法资料，未执行验证；不改变随包支持声明。API、边界和外部参数见 [读取约定](../../reading.md)。

## 格式入口

| 标识/API | 扩展名 | 文件头候选（u32 小端字节） | 来源写入声明 |
|---|---|---|---|
| `IFL` / `GameRes.Formats.Silky.IflOpener` | `ifl` | `49464c53` | `False` |

## 字段与结构读取

以下保留源码的偏移表达式。`entry.Offset` 为最终成员跨度；`base_offset + offset` 等表达式中的基址以算法摘录为准。表中重复读取可属于不同版本或分支，不能拼成一个假定的统一头部。

| 算法位置 | 读取表达式 |
|---|---|
| `IflOpener.TryOpen` | `uint data_offset = file.View.ReadUInt32 (4);` |
| `IflOpener.TryOpen` | `int count = file.View.ReadInt32 (8);` |
| `IflOpener.TryOpen` | `string name = file.View.ReadString (index_offset, 0x10);` |
| `IflOpener.TryOpen` | `entry.Offset = file.View.ReadUInt32 (index_offset+0x10);` |
| `IflOpener.TryOpen` | `entry.Size   = file.View.ReadUInt32 (index_offset+0x14);` |
| `IflOpener.OpenEntry` | `\|\| !arc.File.View.AsciiEqual (entry.Offset, "CMP_"))` |
| `IflOpener.OpenEntry` | `pent.UnpackedSize = arc.File.View.ReadUInt32 (entry.Offset+4);` |

## 读取、解密与解压步骤

按所属类和入口选择分支，固定常量只用于引用它们的方言。外部方案库需要显式参数；摘录省略 writer、GUI 和资源注册。

### GameRes.Formats.Silky.IflOpener

继承/接口：`ArchiveFormat`。

#### TryOpen

```csharp
public override ArcFile TryOpen (ArcView file) {
    uint data_offset = file.View.ReadUInt32 (4);
    int count = file.View.ReadInt32 (8);
    if (!IsSaneCount (count) || data_offset <= 12 || data_offset >= file.MaxOffset)
        return null;
    var dir = new List<Entry> (count);
    long index_offset = 12;
    for (int i = 0; i < count; ++i)
    {
        string name = file.View.ReadString (index_offset, 0x10);
        if (0 == name.Length)
            return null;
        var entry = FormatCatalog.Instance.Create<PackedEntry> (name);
        entry.Offset = file.View.ReadUInt32 (index_offset+0x10);
        entry.Size   = file.View.ReadUInt32 (index_offset+0x14);
        if (!entry.CheckPlacement (file.MaxOffset))
            return null;
        dir.Add (entry);
        index_offset += 0x18;
    }
    return new ArcFile (file, this, dir);
}
```

#### OpenEntry

```csharp
public override Stream OpenEntry (ArcFile arc, Entry entry) {
    var pent = (PackedEntry)entry;
    if (!pent.IsPacked)
    {
        if (entry.Size <= 12
            || entry.Name.HasExtension (".grd")
            || !arc.File.View.AsciiEqual (entry.Offset, "CMP_"))
            return arc.File.CreateStream (entry.Offset, entry.Size);
        pent.IsPacked = true;
        pent.UnpackedSize = arc.File.View.ReadUInt32 (entry.Offset+4);
    }
    using (var input = arc.File.CreateStream (entry.Offset+12, entry.Size-12))
    using (var lzss = new LzssReader (input, (int)input.Length, (int)pent.UnpackedSize))
    {
        lzss.FrameFill = 0x20;
        lzss.Unpack();
        return new BinMemoryStream (lzss.Data, entry.Name);
    }
}
```

## 配套算法与外部条件

- [ArcFormats/LzssStream.cs](../LzssStream.md)：本页引用的随包算法资料。

## 出处与许可

来源文件标识 `ArcFormats/Silky/ArcIFL.cs`；版本、UTF-8 解码内容哈希与版权/许可通知见 [出处清单](../../../../provenance/garbro-archive-excerpts.json)和 [原通知](../../../../provenance/garbro-archive-notices.md)。路径是出处，不是使用时需要访问的外部文件。
