# ArcFormats / Crc64：归档读取与解码

算法资料，未执行验证；不改变随包支持声明。API、边界和外部参数见 [读取约定](../reading.md)。

## 格式入口

| 标识/API | 扩展名 | 文件头候选（u32 小端字节） | 来源写入声明 |
|---|---|---|---|
| 辅助算法 | 由调用入口决定 | 不单独识别容器 | 不作支持声明 |

## 字段与结构读取

以下保留源码的偏移表达式。`entry.Offset` 为最终成员跨度；`base_offset + offset` 等表达式中的基址以算法摘录为准。表中重复读取可属于不同版本或分支，不能拼成一个假定的统一头部。

| 算法位置 | 读取表达式 |
|---|---|
| 辅助算法 | 不独立读取索引；见调用入口和下面的变换步骤 |

## 读取、解密与解压步骤

按所属类和入口选择分支，固定常量只用于引用它们的方言。外部方案库需要显式参数；摘录省略 writer、GUI 和资源注册。

### GameRes.Utility.Crc64

#### 状态与常量

```csharp
const ulong Polynomial = 0x42F0E1EBA9EA3693ul ;

private static readonly ulong[] crc_table = InitializeTable (Polynomial) ;

public static ulong[] Table { get { return crc_table; } }

private ulong m_crc = ~0ul ;

public  ulong Value { get { return ~m_crc; } }
```

#### InitializeTable

```csharp
private static ulong[] InitializeTable (ulong poly) {
    var table = new ulong[256];
    for (uint i = 0; i < 256; ++i)
    {
        ulong crc = (ulong)i << 56;
        for (int j = 0; j < 8; ++j)
        {
            if ((crc >> 63) != 0)
                crc = (crc << 1) ^ poly;
            else
                crc <<= 1;
        }
        table[i] = crc;
    }
    return table;
}
```

#### UpdateCrc

```csharp
public static ulong UpdateCrc (ulong crc, byte[] buf, int pos, int len) {
    for (int n = 0; n < len; n++)
        crc = crc_table[((crc >> 56) ^ buf[pos+n]) & 0xFF] ^ (crc << 8);
    return crc;
}
```

#### Compute

```csharp
public static ulong Compute (byte[] buf, int pos, int len) {
    return ~UpdateCrc (~0ul, buf, pos, len);
}
```

#### Update

```csharp
public void Update (byte[] buf, int pos, int len) {
    m_crc = UpdateCrc (m_crc, buf, pos, len);
}
```

## 配套算法与外部条件

本源文件没有解析到其他专用算法依赖；标准压缩、框架 API 和显式游戏参数的约定仍见读取约定。

## 出处与许可

来源文件标识 `ArcFormats/Crc64.cs`；版本、UTF-8 解码内容哈希与版权/许可通知见 [出处清单](../../../provenance/garbro-archive-excerpts.json)和 [原通知](../../../provenance/garbro-archive-notices.md)。路径是出处，不是使用时需要访问的外部文件。
