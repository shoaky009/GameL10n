# Nexas / ArcTPF：归档读取与解码

算法资料，未执行验证；不改变随包支持声明。API、边界和外部参数见 [读取约定](../../reading.md)。

## 格式入口

| 标识/API | 扩展名 | 文件头候选（u32 小端字节） | 来源写入声明 |
|---|---|---|---|
| `TPF` / `GameRes.Formats.Giga.TpfOpener` | `tpf` | `54504620` | `False` |

## 字段与结构读取

以下保留源码的偏移表达式。`entry.Offset` 为最终成员跨度；`base_offset + offset` 等表达式中的基址以算法摘录为准。表中重复读取可属于不同版本或分支，不能拼成一个假定的统一头部。

| 算法位置 | 读取表达式 |
|---|---|
| `TpfOpener.TryOpen` | `if (!file.View.AsciiEqual (4, "FILE"))` |
| `TpfOpener.TryOpen` | `int count = file.View.ReadInt32 (0xC);` |
| `TpfOpener.TryOpen` | `var name = file.View.ReadString (index_offset, 0x20);` |
| `TpfOpener.TryOpen` | `byte compression = file.View.ReadByte (index_offset+0x23);` |
| `TpfOpener.TryOpen` | `entry.Offset = file.View.ReadUInt32 (index_offset+0x24);` |
| `TpfOpener.TryOpen` | `entry.InterimSize = file.View.ReadUInt32 (index_offset+0x28);` |
| `TpfOpener.TryOpen` | `entry.UnpackedSize = file.View.ReadUInt32 (index_offset+0x2C);` |
| `TpfOpener.TryOpen` | `entry.Size = (uint)(file.View.ReadUInt32 (index_offset+0x24) - entry.Offset);` |

## 读取、解密与解压步骤

按所属类和入口选择分支，固定常量只用于引用它们的方言。外部方案库需要显式参数；摘录省略 writer、GUI 和资源注册。

### GameRes.Formats.Giga.TpfEntry

继承/接口：`PackedEntry`。

#### 状态与常量

```csharp
public uint InterimSize ;

public byte Compression ;
```

### GameRes.Formats.Giga.TpfOpener

继承/接口：`ArchiveFormat`。

#### TryOpen

```csharp
public override ArcFile TryOpen (ArcView file) {
    if (!file.View.AsciiEqual (4, "FILE"))
        return null;
    int count = file.View.ReadInt32 (0xC);
    if (!IsSaneCount (count))
        return null;

    uint index_offset = 0x10;
    var dir = new List<Entry> (count);
    for (int i = 0; i < count; ++i)
    {
        var name = file.View.ReadString (index_offset, 0x20);
        byte compression = file.View.ReadByte (index_offset+0x23);
        var entry = FormatCatalog.Instance.Create<TpfEntry> (name);
        entry.Compression = compression;
        entry.IsPacked = compression != 0;
        entry.Offset = file.View.ReadUInt32 (index_offset+0x24);
        entry.InterimSize = file.View.ReadUInt32 (index_offset+0x28);
        entry.UnpackedSize = file.View.ReadUInt32 (index_offset+0x2C);
        index_offset += 0x30;
        if (entry.UnpackedSize != 0)
        {
            entry.Size = (uint)(file.View.ReadUInt32 (index_offset+0x24) - entry.Offset);
            if (!entry.CheckPlacement (file.MaxOffset))
                return null;
            dir.Add (entry);
        }
    }
    return new ArcFile (file, this, dir);
}
```

#### OpenEntry

```csharp
public override Stream OpenEntry (ArcFile arc, Entry entry) {
    Stream input = arc.File.CreateStream (entry.Offset, entry.Size);
    var pent = entry as TpfEntry;
    if (null == pent || !pent.IsPacked || pent.Compression > 2)
        return input;
    if (2 == pent.Compression)
        input = new HuffmanStream (input);
    return new LzssStream (input);
}
```

## 配套算法与外部条件

- [ArcFormats/HuffmanCompression.cs](../HuffmanCompression.md)：本页引用的随包算法资料。
- [ArcFormats/LzssStream.cs](../LzssStream.md)：本页引用的随包算法资料。

## 出处与许可

来源文件标识 `ArcFormats/Nexas/ArcTPF.cs`；版本、UTF-8 解码内容哈希与版权/许可通知见 [出处清单](../../../../provenance/garbro-archive-excerpts.json)和 [原通知](../../../../provenance/garbro-archive-notices.md)。路径是出处，不是使用时需要访问的外部文件。
