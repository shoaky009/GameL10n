import sys
import os
import struct
import json
import re
import time
import shutil
import csv
import tempfile
from contextlib import suppress
import siglus_ssu as _runtime
from . import const as C, package_version
from .BS import (
    compile_all,
    compile_one,
    set_shuffle_seed,
    get_shuffle_seed,
    build_ia_data,
    empty_source_stat_counts,
)
from .GEI import write_gameexe_dat
from .linker import link_pack
from .native_ops import (
    lzss_pack,
    xor_cycle_inplace,
    smd5_digest,
    tile_copy,
    compile_project_native,
    is_native_available,
)
from .common import (
    ascii_lower,
    looks_like_siglus_dat,
    record_stage_time,
    build_source_angou_layout,
    content_digest,
    decode_text_auto,
    read_bytes,
    read_scn_header,
    read_exe_el_key,
    read_text_auto,
    first_line_text,
    angou_first_line,
    write_bytes,
    write_text,
    parse_code,
    ANGOU_DAT_NAME,
    KEY_TXT_NAME,
    MACRO_STAT_KINDS,
    has_option,
    empty_macro_stat_counts,
    norm_charset,
    format_scene_name,
    merge_macro_stat_counts,
    scene_string_xor_key,
    split_end_of_options,
)
from .path_policy import (
    FilenameCaseCollisionError,
    read_directory,
    resolve_read_path,
    walk_read_directory,
    windows_filename_key,
)


class _CompileCacheLock:
    def __init__(self, directory):
        self.file = open(os.path.join(directory, "_compile.lock"), "a+b")
        self.locked = False
        try:
            self.file.seek(0, os.SEEK_END)
            if self.file.tell() == 0:
                self.file.write(b"\0")
                self.file.flush()
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.file.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.file.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            self.locked = True
        except (OSError, RuntimeError) as exc:
            self.file.close()
            raise RuntimeError(f"--tmp is already in use: {directory}") from exc

    def close(self):
        if not self.locked:
            return
        try:
            self.file.seek(0)
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(self.file.fileno(), msvcrt.LK_UNLCK, 1)
            else:
                import fcntl

                fcntl.flock(self.file.fileno(), fcntl.LOCK_UN)
        finally:
            self.locked = False
            self.file.close()


SCENE_SCRIPT_ID_PREFIX = b"// #SCENE_SCRIPT_ID = "


def source_angou_encrypt(data: bytes, name: str, ctx: dict) -> bytes:
    sa = ctx.get("source_angou")
    if not sa:
        raise ValueError(
            "source_angou_encrypt requires ctx['source_angou'] (dict with codes and header_size)"
        )
    eg = parse_code(sa.get("easy_code"))
    mg = parse_code(sa.get("mask_code"))
    gg = parse_code(sa.get("gomi_code"))
    lg = parse_code(sa.get("last_code"))
    ng = parse_code(sa.get("name_code"))
    missing_codes = [
        n
        for n, v in (
            ("easy_code", eg),
            ("mask_code", mg),
            ("gomi_code", gg),
            ("last_code", lg),
            ("name_code", ng),
        )
        if not v
    ]
    if missing_codes:
        raise ValueError(
            "source_angou_encrypt: missing codes: " + ", ".join(missing_codes)
        )
    hs = sa.get("header_size")
    if not hs:
        raise ValueError("source_angou_encrypt: missing header_size")
    lz = lzss_pack(data)
    lzsz = len(lz)
    b = bytearray(lz)
    xor_cycle_inplace(b, eg, int(sa.get("easy_index", 0)))
    lz = bytes(b)
    smd5 = smd5_digest(lz)
    smd5_code = bytearray(68)
    smd5_code[: len(smd5)] = smd5
    n0x40 = lzsz
    struct.pack_into("<I", smd5_code, 64, n0x40)
    nameb = bytearray((name or "").encode("utf-16le"))
    xor_cycle_inplace(nameb, ng, int(sa.get("name_index", 0)))
    mw, mh, mask, mapw, maph, mapt, bh = build_source_angou_layout(
        smd5_code, sa, mg, lzsz
    )
    lzb = bytearray(lz) + bytearray(mapt * 2 - lzsz)
    cnt = len(lzb) - lzsz
    if cnt > 0:
        ind = int(sa.get("gomi_index", 0))
        mi = int(sa.get("gomi_md5_index", 0))
        for i in range(cnt):
            gomi_smd5_ofs = (mi % 16) * 4
            lzb[lzsz + i] = gg[ind % len(gg)] ^ smd5_code[gomi_smd5_ofs]
            ind += 1
            mi = (mi + 1) % 16
    header = bytearray(hs)
    struct.pack_into("<I", header, 0, 1)
    header[4:hs] = smd5_code
    out = bytearray(hs + 4 + len(nameb) + mapt * 2)
    out[0:hs] = header
    struct.pack_into("<I", out, hs, len(nameb))
    p = hs + 4
    out[p : p + len(nameb)] = nameb
    dp1 = p + len(nameb)
    dp2 = dp1 + mapt
    sp1 = 0
    sp2 = bh
    repx = int(sa.get("tile_repx", 0))
    repy = int(sa.get("tile_repy", 0))
    lim = int(sa.get("tile_limit", 0))
    out_mv = memoryview(out)
    lzb_mv = memoryview(lzb)
    for dest, source, reverse in (
        (dp1, sp1, 0),
        (dp1, sp2, 1),
        (dp2, sp1, 1),
        (dp2, sp2, 0),
    ):
        tile_copy(
            out_mv[dest : dest + mapt],
            lzb_mv[source : source + mapt],
            mapw,
            maph,
            mask,
            mw,
            mh,
            repx,
            repy,
            reverse,
            lim,
        )
    xor_cycle_inplace(out, lg, int(sa.get("last_index", 0)))
    return bytes(out)


def _is_int_token(t):
    if t is None:
        return False
    s = str(t).strip()
    if not s:
        return False
    if re.fullmatch(r"0[xX][0-9a-fA-F]+", s):
        return True
    return re.fullmatch(r"[0-9]+", s) is not None


def _parse_u32_token(t, opt):
    s = str(t).strip() if t is not None else ""
    if not _is_int_token(s):
        raise ValueError(f"{opt} expects a u32 integer")
    if s.startswith(("0x", "0X")):
        n = int(s[2:], 16)
    else:
        n = int(s, 10)
    if n < 0 or n > 0xFFFFFFFF:
        raise ValueError(f"{opt} expects a u32 integer")
    return n


def _write_digest_cache(path, payload):
    tmp_path = path + ".tmp"
    try:
        write_text(
            tmp_path,
            json.dumps(payload, ensure_ascii=False, sort_keys=True),
            enc="utf-8",
        )
        os.replace(tmp_path, path)
    except Exception:
        with suppress(OSError):
            os.remove(tmp_path)
        raise


def _compile_cache_state(
    *, tmp_dir, enc, charset, ss, source_digests, incremental, allow_invalid
):
    compile_list = list(ss or [])
    digest_path = os.path.join(tmp_dir, "_source_hashes.json") if tmp_dir else ""
    cur_inc = source_digests["inc"]
    cur_ss = source_digests["ss"]
    full_compile = True
    cache_meta = {
        "schema": 9,
        "siglus_ssu_version": str(package_version() or ""),
        "charset": enc,
        "charset_force": charset,
        "allow_invalid": bool(allow_invalid),
        "const_profile": C.CONST_PROFILE,
        "const_sha512": C.CONST_SHA512,
        "scene_string_xor_multiplier": _runtime._SCENE_STRING_XOR_MULTIPLIER,
    }
    if incremental:
        old = None
        try:
            existing_digest_path = resolve_read_path(digest_path, kind="file")
        except (FileNotFoundError, NotADirectoryError):
            existing_digest_path = ""
        if existing_digest_path:
            try:
                old = json.loads(
                    read_text_auto(existing_digest_path, force_charset="utf-8")
                )
            except FilenameCaseCollisionError:
                raise
            except Exception:
                old = None
        full_compile = False
        if not isinstance(old, dict):
            full_compile = True
        else:
            old_meta = old.get("meta") or {}
            if old_meta != cache_meta:
                full_compile = True
            else:
                old_inc = old.get("inc") or {}
                for k in cur_inc.keys() | old_inc.keys():
                    if str(cur_inc.get(k, "")) != str(old_inc.get(k, "")):
                        full_compile = True
                        break
        bs_dir = os.path.join(tmp_dir, "bs")
        if full_compile:
            compile_list = list(ss or [])
        else:
            old_ss = old.get("ss") or {}
            comp = set()
            for p in ss or []:
                b = ascii_lower(os.path.basename(p))
                nm = os.path.splitext(os.path.basename(p))[0]
                dat_path = os.path.join(bs_dir, nm + ".dat")
                need = str(cur_ss.get(b, "")) != str(old_ss.get(b, ""))
                if not need:
                    try:
                        resolve_read_path(dat_path, kind="file")
                    except (FileNotFoundError, NotADirectoryError):
                        need = True
                if need:
                    comp.add(p)
            compile_list = sorted(comp, key=lambda x: ascii_lower(os.path.basename(x)))
        if existing_digest_path:
            os.remove(existing_digest_path)
        for p in compile_list:
            name = os.path.splitext(os.path.basename(p))[0] + ".dat"
            try:
                existing_dat_path = resolve_read_path(
                    os.path.join(bs_dir, name), kind="file"
                )
            except (FileNotFoundError, NotADirectoryError):
                continue
            if os.path.basename(existing_dat_path) != name:
                os.remove(existing_dat_path)
    pending_digests = {"inc": cur_inc, "meta": cache_meta, "ss": cur_ss}
    return compile_list, digest_path, pending_digests, full_compile


def _native_cache_read_paths(tmp_dir, ss, compile_list, use_lzss):
    compiled = {
        ascii_lower(os.path.splitext(os.path.basename(path))[0])
        for path in compile_list or []
    }
    dat_paths = {}
    lzss_paths = {}
    for path in ss or []:
        stem = os.path.splitext(os.path.basename(path))[0]
        key = ascii_lower(stem)
        if key in compiled:
            continue
        candidate = os.path.join(tmp_dir, "bs", stem + ".dat")
        try:
            dat_paths[key] = resolve_read_path(candidate, kind="file")
        except (FileNotFoundError, NotADirectoryError):
            pass
        if use_lzss:
            candidate = os.path.join(tmp_dir, "bs", stem + ".lzss")
            try:
                lzss_paths[key] = resolve_read_path(candidate, kind="file")
            except (FileNotFoundError, NotADirectoryError):
                pass
    return dat_paths, lzss_paths


def _native_compile_cache_config(
    *, args, tmp_dir, enc, charset, ss, source_digests, test_shuffle
):
    compile_list, digest_path, pending_digests, full_compile = _compile_cache_state(
        tmp_dir=tmp_dir,
        enc=enc,
        charset=charset,
        ss=ss,
        source_digests=source_digests,
        incremental=bool(args.tmp_dir),
        allow_invalid=args.allow_invalid,
    )
    dat_paths, lzss_paths = _native_cache_read_paths(
        tmp_dir,
        ss,
        compile_list,
        use_lzss=not args.no_angou and not args.no_lzss,
    )
    lzss_remove_paths = []
    if args.tmp_dir:
        bs_dir = os.path.join(tmp_dir, "bs")
        if full_compile:
            try:
                _, entries = read_directory(bs_dir)
            except (FileNotFoundError, NotADirectoryError):
                entries = []
            lzss_remove_paths = [
                entry.path
                for entry in entries
                if entry.is_file() and entry.name.lower().endswith(".lzss")
            ]
        else:
            for path in compile_list:
                stem = os.path.splitext(os.path.basename(path))[0]
                candidate = os.path.join(bs_dir, stem + ".lzss")
                try:
                    lzss_remove_paths.append(resolve_read_path(candidate, kind="file"))
                except (FileNotFoundError, NotADirectoryError):
                    pass
    full_compile_stats = (
        (not args.dat_repack)
        and not args.tmp_dir
        and (not test_shuffle)
        and bool(ss)
        and len(compile_list) == len(ss or [])
    )
    return {
        "digest_path": digest_path,
        "pending_digests_json": json.dumps(
            pending_digests, ensure_ascii=False, sort_keys=True
        ),
        "compile_scene_names": [os.path.basename(p) for p in compile_list],
        "dat_paths": dat_paths,
        "lzss_paths": lzss_paths,
        "lzss_remove_paths": lzss_remove_paths,
        "compiled_scene_files": len(compile_list or []),
        "full_compile_stats": bool(full_compile_stats),
    }


def _tmp_incompatible_options(argv, test_shuffle=False):
    bad = []
    if test_shuffle:
        bad.append("--test-shuffle")
    for opt in (
        "--dat-repack",
        "--csv",
        "--gei",
        "--set-shuffle",
        "--no-angou",
        "--no-lzss",
        "--debug",
    ):
        if has_option(argv, opt):
            bad.append(opt)
    return bad


def _read_scn_dat(path):
    b = read_bytes(path)
    h = read_scn_header(b)
    if not h:
        raise ValueError(f"{path}: bad dat header")
    ofs = h.get("str_index_list_ofs", 0)
    cnt = h.get("str_index_cnt", 0)
    if cnt < 0:
        raise ValueError("bad str_index_cnt")
    if ofs < C.SCN_HDR_SIZE or ofs + cnt * 8 > len(b):
        raise ValueError("bad str_index_list")
    idx = [struct.unpack_from("<ii", b, ofs + i * 8) for i in range(cnt)]
    return b, h, idx


def _read_scn_dat_header(path):
    h = read_scn_header(read_bytes(path))
    if not h:
        raise ValueError(f"{path}: bad dat header")
    return h


def _read_scn_dat_str_pool(path):
    b, h, idx = _read_scn_dat(path)
    order = sorted(range(len(idx)), key=lambda o: idx[o][0])
    base = h.get("str_list_ofs", 0)
    out = []
    for orig in order:
        ofs_u16, ln_u16 = idx[orig]
        if ln_u16 <= 0:
            out.append("")
            continue
        p = base + ofs_u16 * 2
        q = p + ln_u16 * 2
        if p < 0 or q > len(b):
            raise ValueError("bad str_list range")
        k = scene_string_xor_key(orig)
        mask = k.to_bytes(2, "little") * ln_u16
        value = int.from_bytes(b[p:q], "little") ^ int.from_bytes(mask, "little")
        out.append(value.to_bytes(q - p, "little").decode("utf-16le", "surrogatepass"))
    return out


def _write_test_shuffle_csv(csv_path, rows):
    if not csv_path:
        return
    os.makedirs(os.path.dirname(csv_path) or ".", exist_ok=True)
    with open(csv_path, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.writer(f, lineterminator="\r\n")
        w.writerow(
            [
                "object",
                "initial_seed",
                "initial_seed_hex",
                "final_seed",
                "final_seed_hex",
                "matched",
            ]
        )
        for row in rows or []:
            initial_seed = int(row.get("initial_seed", 0) or 0) & 0xFFFFFFFF
            final_seed = int(row.get("final_seed", 0) or 0) & 0xFFFFFFFF
            w.writerow(
                [
                    row.get("object", ""),
                    initial_seed,
                    f"0x{initial_seed:08X}",
                    final_seed,
                    f"0x{final_seed:08X}",
                    int(bool(row.get("matched"))),
                ]
            )


def _scene_ssid_from_text(text):
    prefix = SCENE_SCRIPT_ID_PREFIX.decode("ascii")
    line = str(text or "").split("\n", 1)[0]
    if (not line.startswith(prefix)) or (len(line) < (len(prefix) + 4)):
        return None
    raw = line[len(prefix) : len(prefix) + 4]
    if len(raw) != 4 or not raw.isascii() or not raw.isdigit():
        return None
    return int(raw)


def _scan_dir(p):
    _, entries = read_directory(p)
    fs = [entry.name for entry in entries if entry.is_file()]
    fs.sort(key=ascii_lower)
    ini = [f for f in fs if ascii_lower(os.path.splitext(f)[1]) in (".ini", ".dat")]
    inc = [f for f in fs if ascii_lower(f).endswith(".inc")]
    ss = []
    scn_ssid_map = {}
    for f in fs:
        if not ascii_lower(f).endswith(".ss"):
            continue
        fp = os.path.join(p, f)
        ss.append(fp)
        scn_ssid_map[ascii_lower(f)] = None
        scn_ssid_map[ascii_lower(os.path.splitext(f)[0])] = None
    return fs, ini, inc, ss, scn_ssid_map


def _guess_charset(source_bytes, ini, inc, ss):
    names = [*(os.path.basename(path) for path in ss), *inc, *ini]
    for name in names:
        b = source_bytes.get(name)
        if b is None:
            continue
        b = b.partition(b"\x1a")[0]
        if b.startswith(b"\xef\xbb\xbf"):
            return "utf-8"
        try:
            t = b.decode("utf-8", "strict")
        except UnicodeDecodeError:
            continue
        if any(
            0x3040 <= ord(ch) <= 0x30FF
            or 0x4E00 <= ord(ch) <= 0x9FFF
            or 0x3400 <= ord(ch) <= 0x4DBF
            for ch in t
        ):
            return "utf-8"
    return "cp932"


def _load_project_sources(
    base_dir, gameexe_ini, inc, ss, charset, original_files, *, allow_invalid
):
    paths = {}
    if gameexe_ini:
        paths[gameexe_ini] = None
    paths.update((name, "inc") for name in inc)
    paths.update((os.path.basename(path), "ss") for path in ss)
    texts = {}
    digests = {"inc": {}, "ss": {}}
    source_bytes = {}
    for name in dict.fromkeys([*paths, *original_files]):
        path = os.path.join(base_dir, name)
        try:
            data = read_bytes(resolve_read_path(path, kind="file"))
            source_bytes[name] = data
            if name in paths:
                texts[name] = decode_text_auto(
                    data,
                    force_charset=charset,
                    stop_at_dos_eof=True,
                    allow_invalid=allow_invalid,
                )[0]
                kind = paths[name]
                if kind is not None:
                    digests[kind][ascii_lower(name)] = content_digest(data)
        except UnicodeError as exc:
            raise ValueError(f"{path}: {exc}") from exc
    return texts, digests, source_bytes


def _collect_macro_stats(ctx, compile_stats):
    iad = ctx["ia_data"]
    macro_counts = empty_macro_stat_counts()
    is_parallel = compile_stats["parallel"]
    usage_delta = compile_stats["global_macro_usage_delta"]
    for rep in iad["macro_defs"]:
        kind = rep["decl_type"]
        name = rep["name"]
        bucket = macro_counts[kind]
        bucket["total"] += 1
        used = rep["used_count"]
        if is_parallel:
            used += usage_delta.get((kind, name), 0)
        if used <= 0:
            bucket["unused"] += 1
    merge_macro_stat_counts(macro_counts, compile_stats["scene_macro_counts"])
    return macro_counts


def _collect_read_flag_stats(bs_dir, scene_paths):
    total = 0
    scene_total = 0
    scene_counts = []
    for scene_path in scene_paths:
        nm = os.path.splitext(os.path.basename(scene_path))[0]
        dat_path = os.path.join(bs_dir, nm + ".dat")
        header = _read_scn_dat_header(dat_path)
        cnt = header["read_flag_cnt"]
        total += cnt
        if cnt > 0:
            scene_total += 1
            scene_counts.append((nm, cnt))
    scene_counts.sort(key=lambda item: (-item[1], ascii_lower(item[0]), item[0]))
    return total, scene_total, scene_counts[:5]


def _finalize_source_stats(ctx, compile_stats):
    source_stats = compile_stats["source_stats"]
    iad = ctx["ia_data"]
    directives = source_stats["directives"]
    global_props = iad["inc_property_cnt"]
    global_cmds = iad["inc_command_cnt"]
    scene_props = directives["scene_inc_properties"]
    scene_cmds = directives["scene_inc_commands"]
    directives["global_inc_properties"] = global_props
    directives["global_inc_commands"] = global_cmds
    directives["property_directives_total"] = global_props + scene_props
    directives["command_directives_total"] = global_cmds + scene_cmds
    strings = source_stats["strings"]
    strings["unique"] = len(source_stats["_unique_strings"])
    strings["unique_speaker_names"] = len(source_stats["_unique_speakers"])
    return source_stats


def _sorted_counter_text(counter, sep="="):
    if not counter:
        return "none"
    return " ".join(f"{name}{sep}{count}" for name, count in sorted(counter.items()))


def _top_scene_text(items, value_key, extra_key=None):
    if not items:
        return "none"
    rows = sorted(
        items,
        key=lambda item: (
            -item[value_key],
            ascii_lower(item["name"]),
            item["name"],
        ),
    )
    out = []
    for item in rows[:5]:
        name = item["name"]
        value = item[value_key]
        if extra_key:
            out.append(f"{name}({value}, {extra_key}={item[extra_key]})")
        else:
            out.append(f"{name}({value})")
    return ", ".join(out)


def _print_source_stats(source_stats):
    directives = source_stats["directives"]
    pre = source_stats["preprocess"]
    inc = source_stats["inc"]
    strings = source_stats["strings"]
    statements = source_stats["statements"]
    labels = source_stats["labels"]
    expressions = source_stats["expressions"]
    print(
        "#property: "
        f"global={directives.get('global_inc_properties', 0)} "
        f"scene_local={directives.get('scene_inc_properties', 0)}"
    )
    print(
        "#command: "
        f"global={directives.get('global_inc_commands', 0)} "
        f"scene_local={directives.get('scene_inc_commands', 0)} "
        f"global_impl={directives.get('global_command_implementations', 0)} "
        f"scene_defs={directives.get('scene_command_definitions', 0)}"
    )
    print(
        "preprocessor: "
        f"ifdef={pre.get('ifdef', 0)} "
        f"elseifdef={pre.get('elseifdef', 0)} "
        f"else={pre.get('else', 0)} "
        f"endif={pre.get('endif', 0)} "
        f"max_depth={pre.get('max_ifdef_depth', 0)} "
        f"excluded_lines={pre.get('excluded_lines', 0)}"
    )
    print(
        "inc_blocks: "
        f"start={inc.get('blocks', 0)} "
        f"end={inc.get('ends', 0)} "
        f"lines={inc.get('lines', 0)}"
    )
    print(
        "labels: "
        f"defs={labels.get('defs', 0)} "
        f"refs={labels.get('refs', 0)} "
        f"unused={labels.get('unused', 0)} "
        f"z_defs={labels.get('z_defs', 0)} "
        f"z_refs={labels.get('z_refs', 0)} "
        f"z_unused={labels.get('z_unused', 0)} "
        f"generated={labels.get('generated', 0)}"
    )
    print(
        "statements: "
        + _sorted_counter_text(
            {
                key: value
                for key, value in statements.items()
                if key
                not in (
                    "assign",
                    "command_def",
                    "eof",
                    "label",
                    "name",
                    "text",
                    "z_label",
                )
            }
        )
    )
    print(
        "expressions: "
        f"max_depth={expressions.get('max_depth', 0)} "
        f"named_args={expressions.get('named_args', 0)} "
        f"default_arg_fills={expressions.get('default_arg_fills', 0)}"
    )
    print("assign_ops: " + _sorted_counter_text(expressions["assign_ops"], ":"))
    print("unary_ops: " + _sorted_counter_text(expressions["unary_op_kinds"], ":"))
    print("binary_ops: " + _sorted_counter_text(expressions["binary_op_kinds"], ":"))
    print(
        "strings: "
        f"entries={strings.get('entries', 0)} "
        f"unique={strings.get('unique', 0)} "
        f"utf16_units={strings.get('utf16_units', 0)}"
    )
    print(
        "dialogue: "
        f"text_lines={strings.get('dialogue_text_lines', 0)} "
        f"speaker_names={strings.get('speaker_names', 0)} "
        f"unique_speaker_names={strings.get('unique_speaker_names', 0)}"
    )


def _print_top_stats(stats):
    top5 = stats["top5_read_flags_scenes"]
    if top5:
        print(
            "top5_read_flags_scenes: "
            + ", ".join(f"{name}({count})" for name, count in top5)
        )
    else:
        print("top5_read_flags_scenes: none")
    print(
        "top5_string_pool_scenes: "
        + _top_scene_text(
            stats["source_stats"]["strings"]["top_scenes"],
            "utf16_units",
            "entries",
        )
    )
    print(
        "top5_dat_scenes: "
        + _top_scene_text(stats["binary_size_stats"]["top_dat_scenes"], "dat_bytes")
    )


def _print_summary(ctx, ok=False):
    stats = ctx["stats"]
    timings = stats["stage_time"]
    angou = stats["angou_content"]
    has_compile_stats = (
        bool(timings)
        or stats["inc_files"] > 0
        or stats["scene_files"] > 0
        or stats["compiled_scene_files"] > 0
    )
    if has_compile_stats:
        print("=== Compiling Stats ===")
        for k in sorted(timings.keys()):
            print(f"{k}: {timings[k]:.3f}s")
        print(f"inc_files: {stats['inc_files']}")
        print(f"scene_files: {stats['scene_files']}")
        print(f"compiled_scene_files: {stats['compiled_scene_files']}")
        if ok and stats["full_compile_stats"]:
            for kind in MACRO_STAT_KINDS:
                bucket = stats["macro_counts"][kind]
                print(f"#{kind}: total={bucket['total']} unused={bucket['unused']}")
            print(f"read_flags: {stats['read_flags']}")
            print(f"read_flags_scenes: {stats['read_flags_scenes']}")
            _print_source_stats(stats["source_stats"])
            binary_stats = stats["binary_size_stats"]
            ratio = binary_stats["lzss_ratio"]
            ratio_text = f"{float(ratio):.3f}" if ratio is not None else "n/a"
            print(
                "binary_sizes: "
                f"dat_bytes={binary_stats['dat_bytes']} "
                f"scn_bytes={binary_stats['scn_bytes']} "
                f"lzss_bytes={binary_stats['lzss_bytes']} "
                f"lzss_ratio={ratio_text}"
            )
            _print_top_stats(stats)
    if angou is not None:
        print("=== \u6697\u53f7.dat ===")
        print(angou)


def _native_compile_constants_config():
    from .MA import FormTable

    form_table = FormTable()
    form_table.create_system_form_table()
    system_elements = []
    selection_command_codes = []
    for parent, form_info in form_table.form_map_by_name.items():
        for element in (form_info.get("element_map_by_name") or {}).values():
            arg_map = []
            for list_id, arg_list in sorted(
                (element.get("arg_map") or {}).items(), key=lambda item: int(item[0])
            ):
                args_snapshot = []
                source_args = (
                    arg_list.get("arg_list") if isinstance(arg_list, dict) else arg_list
                ) or []
                for index, arg in enumerate(source_args):
                    args_snapshot.append(
                        {
                            "id": int(arg.get("id", index) or index),
                            "name": str(arg.get("name", "") or ""),
                            "form": str(arg.get("form", C.FM_INT) or C.FM_INT),
                            "def_int": int(arg.get("def_int", 0) or 0),
                            "def_exist": bool(arg.get("def_exist", False)),
                            "preserve_int_reference": bool(
                                arg.get("preserve_int_reference", False)
                            ),
                        }
                    )
                arg_map.append({"id": int(list_id), "args": args_snapshot})
            element_code = int(element.get("code", 0) or 0)
            system_elements.append(
                {
                    "parent": str(parent),
                    "kind": int(element.get("type", C.ET_PROPERTY) or 0),
                    "code": element_code,
                    "name": str(element.get("name", "") or ""),
                    "form": str(element.get("form", C.FM_INT) or C.FM_INT),
                    "arg_map": arg_map,
                    "origin": str(element.get("origin", "sys") or "sys"),
                }
            )
            if C.is_global_sel_command(parent, element_code):
                selection_command_codes.append(
                    [int(C._FORM_CODE.get(parent, 0) or 0), element_code]
                )
    return {
        "form_code": dict(C._FORM_CODE),
        "form_names": {
            name: str(getattr(C, name))
            for name in (
                "FM___ARGSREF",
                "FM___ARGS",
                "FM_LIST",
                "FM_VOID",
                "FM_INT",
                "FM_INTLIST",
                "FM_INTLISTREF",
                "FM_INTREF",
                "FM_LABEL",
                "FM_CALL",
                "FM_SCENE",
                "FM_GLOBAL",
                "FM_STR",
                "FM_STRLIST",
                "FM_STRLISTREF",
                "FM_STRREF",
            )
        },
        "la_type": {str(name): int(value) for name, value in C.LA_T.items()},
        "op_code": {
            name: int(getattr(C, name)) for name in dir(C) if name.startswith("OP_")
        },
        "cd_code": {
            name: int(getattr(C, name)) for name in dir(C) if name.startswith("CD_")
        },
        "element_code": {
            "ELM_ARRAY": C.ELM_ARRAY,
            "ELM_GLOBAL_CUR_CALL": C.ELM_GLOBAL_CUR_CALL,
            "ELM_GLOBAL_MSG_BLOCK": C.ELM_GLOBAL_MSG_BLOCK,
            "ELM_OWNER_CALL_PROP": C.ELM_OWNER_CALL_PROP,
            "ELM_OWNER_USER_CMD": C.ELM_OWNER_USER_CMD,
            "ELM_OWNER_USER_PROP": C.ELM_OWNER_USER_PROP,
        },
        "element_type": {
            "ET_COMMAND": C.ET_COMMAND,
            "ET_PROPERTY": C.ET_PROPERTY,
        },
        "system_elements": system_elements,
        "scn_header_fields": list(C.SCN_HDR_FIELDS),
        "scn_header_size": int(C.SCN_HDR_SIZE),
        "pack_header_fields": list(C.PACK_HDR_FIELDS),
        "pack_header_size": int(C.PACK_HDR_SIZE),
        "z_label_count": int(C.TNM_Z_LABEL_CNT),
        "logical_and_precedence": C.LOGICAL_AND_PRECEDENCE,
        "easy_angou_code": bytes(C.EASY_ANGOU_CODE),
        "gameexe_dat_angou_code": bytes(C.GAMEEXE_DAT_ANGOU_CODE),
        "exe_org": bytes(C.EXE_ORG),
        "exe_angou_a_idx": [int(x) for x in C.EXE_ANGOU_A_IDX],
        "exe_angou_b_idx": [int(x) for x in C.EXE_ANGOU_B_IDX],
        "source_angou": dict(C.SOURCE_ANGOU),
        "message_block_command_codes": [
            [int(parent), int(code)] for parent, code in C.MESSAGE_BLOCK_COMMAND_CODES
        ],
        "read_flag_command_codes": [
            [int(parent), int(code)] for parent, code in C.READ_FLAG_COMMAND_CODES
        ],
        "selection_command_codes": selection_command_codes,
        "allow_property_out_of_command": C.ALLOW_PROPERTY_OUT_OF_COMMAND,
        "scene_string_xor_multiplier": _runtime._SCENE_STRING_XOR_MULTIPLIER,
    }


def _native_compile_config(
    *,
    args,
    ctx,
    input_dir,
    output_dir,
    scene_pck,
    tmp_dir,
    ss,
    enc,
    charset_force,
    test_shuffle,
    force_serial_compile,
    angou_content,
):
    if not args.tmp_dir and not args.debug:
        tmp_dir = ""
    scene_display_names = {}
    for scn_name in list(ctx.get("scn_list") or []):
        scene_display_names[os.path.basename(str(scn_name))] = format_scene_name(
            scn_name, ctx
        )
    return {
        "input_dir": input_dir,
        "output_dir": output_dir,
        "scene_pck": scene_pck,
        "tmp_dir": tmp_dir,
        "constants": _native_compile_constants_config(),
        "cache": _native_compile_cache_config(
            args=args,
            tmp_dir=tmp_dir,
            enc=enc,
            charset=charset_force,
            ss=ss,
            source_digests=ctx["source_digests"],
            test_shuffle=test_shuffle,
        ),
        "options": {
            "dat_repack": bool(args.dat_repack),
            "serial": bool(args.serial),
            "max_workers": args.max_workers,
            "set_shuffle": args.set_shuffle,
            "gei": bool(args.gei),
            "test_shuffle": bool(test_shuffle),
            "force_serial_compile": bool(force_serial_compile),
        },
        "context": {
            "gameexe_ini": ctx.get("gameexe_ini"),
            "angou_path": ctx.get("angou_path"),
            "key_path": ctx.get("key_path"),
            "exe_el_key": (
                read_exe_el_key(ctx["key_path"])
                if ctx.get("exe_angou_mode")
                and ctx.get("key_path")
                and not angou_content
                else b""
            ),
            "scn_list": list(ctx.get("scn_list") or []),
            "scene_display_names": scene_display_names,
            "inc_list": list(ctx.get("inc_list") or []),
            "ini_list": list(ctx.get("ini_list") or []),
            "source_texts": dict(ctx.get("source_texts") or {}),
            "source_bytes": ctx["source_bytes"],
            "utf8": bool(ctx.get("utf8")),
            "debug_outputs": bool(ctx.get("debug_outputs")),
            "lzss_mode": bool(ctx.get("lzss_mode")),
            "exe_angou_mode": bool(ctx.get("exe_angou_mode")),
            "source_angou_mode": bool(ctx.get("source_angou_mode")),
            "original_source_mode": bool(ctx.get("original_source_mode")),
            "easy_link": bool(ctx.get("easy_link")),
        },
        "angou_content": angou_content,
    }


def _try_native_compile(config, ctx, *, tmp, tmp_auto, debug):
    result = compile_project_native(config)
    if not isinstance(result, dict):
        sys.stderr.write(
            "warning: Rust compile backend error: invalid native result; falling back to Python\n"
        )
        return None
    if not result.get("handled"):
        fallback_kind = str(result.get("fallback_kind") or "error")
        reason = str(result.get("reason") or "unknown failure")
        sys.stderr.write(
            f"warning: Rust compile backend {fallback_kind}: {reason}; falling back to Python\n"
        )
        return None
    stats = result.get("stats")
    if isinstance(stats, dict):
        ctx.setdefault("stats", {}).update(stats)
    ok = bool(result.get("ok"))
    stderr = str(result.get("stderr") or "")
    if stderr:
        sys.stderr.write(stderr)
        if not stderr.endswith(("\n", "\r")):
            sys.stderr.write("\n")
    _print_summary(ctx, ok=ok)
    if ok and (not debug) and tmp and tmp_auto:
        shutil.rmtree(tmp, ignore_errors=True)
    return 0 if ok else 1


def main(argv):
    import argparse

    prog = "siglus-ssu -c"
    test_shuffle = False
    test_seed0 = 0
    test_seed0_given = False
    test_seed_index = None
    test_dir = ""
    argv = list(argv)
    argv, positional_args = split_end_of_options(argv)
    if "--test-shuffle" in argv:
        i = argv.index("--test-shuffle")
        argv.pop(i)
        test_shuffle = True
        if i < len(argv) and _is_int_token(argv[i]):
            test_seed_index = i
    if test_shuffle and has_option(argv, "--gei"):
        sys.stderr.write(f"{prog}: error: --gei cannot be used with --test-shuffle\n")
        return 2
    if has_option(argv, "--tmp"):
        bad_tmp = _tmp_incompatible_options(argv, test_shuffle=test_shuffle)
        if bad_tmp:
            sys.stderr.write(
                f"{prog}: error: --tmp cannot be used with {', '.join(bad_tmp)}\n"
            )
            return 2
    dat_repack = "--dat-repack" in argv
    if dat_repack:
        if test_shuffle:
            sys.stderr.write(
                f"{prog}: error: --dat-repack is not compatible with --test-shuffle\n"
            )
            return 2
        allowed = {"--dat-repack", "--no-os", "--no-lzss"}
        bad = []
        for t in argv:
            s = str(t)
            if s.startswith("-") and s not in allowed:
                bad.append(s)
        if bad:
            bad = sorted(set(bad))
            sys.stderr.write(
                f"{prog}: error: --dat-repack only supports being used alone or with --no-os/--no-lzss (got: {', '.join(bad)})\n"
            )
            return 2
    test_shuffle_prefix = "[test-shuffle]"

    class _ArgParser(argparse.ArgumentParser):
        def error(self, message):
            raise ValueError(message)

    ap = _ArgParser(prog=prog, add_help=False, allow_abbrev=False)
    if test_shuffle:
        ap.add_argument("input_dir")
        ap.add_argument("output_pck")
        ap.add_argument("test_dir")
    else:
        ap.add_argument("input_dir")
        ap.add_argument("output_pck")
    ap.add_argument("--tmp", dest="tmp_dir", default="")
    ap.add_argument(
        "--charset", default="", help="Force source charset (Python codec name)."
    )
    ap.add_argument(
        "--allow-invalid",
        action="store_true",
        help="Replace invalid source bytes with U+FFFD when decoding.",
    )
    ap.add_argument(
        "--debug",
        action="store_true",
        help="Keep temporary files for debugging purposes.",
    )
    ap.add_argument(
        "--no-os",
        action="store_true",
        help="Remove source chunks after compilation, preserving the package header.",
    )
    ap.add_argument(
        "--dat-repack",
        action="store_true",
        help="Repack existing .dat files in input_dir (skip .ss compilation).",
    )
    ap.add_argument("--no-angou", action="store_true", help="No encrypt/compress.")
    ap.add_argument(
        "--no-lzss",
        action="store_true",
        help="Disable scene LZSS and omit source chunks (official easy link behavior).",
    )
    ap.add_argument(
        "--serial",
        action="store_true",
        help="Disable parallel compilation.",
    )
    ap.add_argument(
        "--max-workers",
        type=int,
        default=None,
        help="Maximum parallel workers for compilation (default: auto; parallel only).",
    )
    ap.add_argument(
        "--set-shuffle",
        dest="set_shuffle",
        default=None,
        help=(
            "Set initial MSVC-compatible shuffle seed for per-script string table order. "
            "Accepts decimal or 0x... (default: 1; implies --serial)."
        ),
    )
    ap.add_argument("--csv", dest="csv_path", default="")
    ap.add_argument("--gei", action="store_true", help="Only generate Gameexe.dat.")
    parse_argv = argv
    if positional_args is not None:
        parse_argv = [*argv, "--", *positional_args]
    try:
        try:
            a = ap.parse_args(parse_argv)
        except ValueError:
            if test_seed_index is None:
                raise
            seeded_argv = list(parse_argv)
            seed_token = seeded_argv.pop(test_seed_index)
            a = ap.parse_args(seeded_argv)
            test_seed0 = _parse_u32_token(seed_token, "--test-shuffle")
            test_seed0_given = True
    except ValueError as exc:
        sys.stderr.write(f"{ap.prog}: error: {exc}\n")
        return 2
    if a.max_workers is not None and a.max_workers <= 0:
        sys.stderr.write(f"{prog}: error: --max-workers must be greater than zero\n")
        return 2
    charset_arg = a.charset or ""
    charset = norm_charset(charset_arg)
    if charset_arg and not charset:
        sys.stderr.write(f"{prog}: error: unsupported --charset: {charset_arg}\n")
        return 2
    test_shuffle_csv_path = str(a.csv_path or "").strip()
    if test_shuffle_csv_path and (
        os.path.isdir(test_shuffle_csv_path)
        or test_shuffle_csv_path.endswith(os.sep)
        or (os.altsep and test_shuffle_csv_path.endswith(os.altsep))
    ):
        test_shuffle_csv_path = os.path.join(
            test_shuffle_csv_path, "test_shuffle_seeds.csv"
        )
    if test_shuffle_csv_path:
        test_shuffle_csv_path = os.path.abspath(test_shuffle_csv_path)
    if test_shuffle_csv_path and not test_shuffle:
        sys.stderr.write(f"{prog}: error: --csv requires --test-shuffle\n")
        return 2
    user_seed = None
    if a.set_shuffle is not None:
        try:
            user_seed = _parse_u32_token(a.set_shuffle, "--set-shuffle")
        except ValueError as exc:
            sys.stderr.write(f"{prog}: error: {exc}\n")
            return 2
    force_serial_compile = bool(a.serial or (user_seed is not None))
    if test_shuffle:
        if (not test_seed0_given) and (user_seed is not None):
            test_seed0 = int(user_seed) & 0xFFFFFFFF
    else:
        if user_seed is not None:
            set_shuffle_seed(int(user_seed) & 0xFFFFFFFF)
    try:
        inp = resolve_read_path(a.input_dir)
    except (FileNotFoundError, NotADirectoryError):
        sys.stderr.write(f"{prog}: error: input_dir not found: {a.input_dir}\n")
        return 1
    gei_ini = ""
    if a.gei and os.path.isfile(inp):
        gei_ini = os.path.basename(inp)
        inp = os.path.dirname(inp) or "."
        inp = os.path.abspath(inp)
    out_pck_arg = str(a.output_pck)
    out_pck = os.path.abspath(out_pck_arg)
    if a.gei:
        out = out_pck
        scene_pck = "Scene.pck"
    elif os.path.isdir(out_pck) or out_pck_arg.endswith(("/", "\\")):
        out = out_pck
        scene_pck = "Scene.pck"
    else:
        out = os.path.dirname(out_pck) or "."
        out = os.path.abspath(out)
        scene_pck = os.path.basename(out_pck)
    if not os.path.isdir(inp):
        sys.stderr.write(
            f"{prog}: error: input_dir is not a directory: {a.input_dir}\n"
        )
        return 1
    if test_shuffle:
        try:
            test_dir = resolve_read_path(a.test_dir or "", kind="dir")
        except (FileNotFoundError, NotADirectoryError):
            sys.stderr.write(f"{prog}: error: test_dir not found: {a.test_dir}\n")
            return 1
    files, ini, inc, ss, scn_ssid_map = _scan_dir(inp)
    if not a.gei and not a.dat_repack and not ss:
        sys.stderr.write(
            f"{prog}: error: input_dir must contain at least one .ss file\n"
        )
        return 1
    if a.dat_repack and not inc:
        sys.stderr.write(
            f"{prog}: warning: --dat-repack found no .inc files; package-level include command metadata will be omitted\n"
        )
    angou_key = windows_filename_key(ANGOU_DAT_NAME)
    key_txt_key = windows_filename_key(KEY_TXT_NAME)
    angou_name = next(
        (name for name in files if windows_filename_key(name) == angou_key), ""
    )
    key_txt_name = next(
        (name for name in files if windows_filename_key(name) == key_txt_key), ""
    )
    if not gei_ini:
        gameexe_key = windows_filename_key("Gameexe.ini")
        gei_ini = next(
            (name for name in ini if windows_filename_key(name) == gameexe_key), ""
        )
    os.makedirs(out, exist_ok=True)
    tmp = ""
    tmp_auto = False
    if not a.gei:
        if a.tmp_dir:
            try:
                tmp = resolve_read_path(a.tmp_dir, kind="dir")
                for _ in walk_read_directory(tmp):
                    pass
            except (FileNotFoundError, NotADirectoryError):
                tmp = os.path.abspath(a.tmp_dir)
            os.makedirs(tmp, exist_ok=True)
        else:
            tmp_auto = True
            tmp = tempfile.mkdtemp(
                prefix="tmp_" + time.strftime("%Y%m%d_%H%M%S", time.localtime()) + "_",
                dir=out,
            )
    original_files = []
    if not a.gei and not a.no_angou and not a.no_lzss:
        original_files = [
            name
            for name in files
            if ascii_lower(name).endswith((".inc", ".ss"))
            or (
                ascii_lower(name).startswith("gameexe")
                and ascii_lower(name).endswith(".ini")
            )
        ]
    try:
        source_texts, source_digests, source_bytes = _load_project_sources(
            inp,
            gei_ini,
            [] if a.gei else inc,
            [] if a.dat_repack or a.gei else ss,
            charset,
            original_files,
            allow_invalid=a.allow_invalid,
        )
    except (OSError, ValueError) as exc:
        sys.stderr.write(f"{prog}: error: {exc}\n")
        return 1
    enc = charset or _guess_charset(source_bytes, ini, inc, ss)
    for path in ss:
        name = os.path.basename(path)
        ssid = _scene_ssid_from_text(source_texts.get(name, ""))
        scn_ssid_map[ascii_lower(name)] = ssid
        scn_ssid_map[ascii_lower(os.path.splitext(name)[0])] = ssid
    use_utf8 = enc != "cp932"
    if not use_utf8:
        for text in source_texts.values():
            try:
                text.encode("cp932", "strict")
            except UnicodeEncodeError:
                use_utf8 = True
                break
    stats = {
        "stage_time": {},
        "inc_files": 0,
        "scene_files": 0,
        "compiled_scene_files": 0,
        "full_compile_stats": False,
        "macro_counts": None,
        "read_flags": None,
        "read_flags_scenes": None,
        "top5_read_flags_scenes": None,
        "source_stats": None,
        "binary_size_stats": None,
    }
    ctx = {
        "project": {},
        "scn_path": inp,
        "tmp_path": tmp,
        "out_path": out,
        "scene_pck": scene_pck,
        "gameexe_ini": gei_ini,
        "angou_path": os.path.join(inp, angou_name) if angou_name else "",
        "key_path": os.path.join(inp, key_txt_name) if key_txt_name else "",
        "scn_list": [os.path.basename(x) for x in ss],
        "scn_ssid_map": scn_ssid_map,
        "inc_list": inc,
        "ini_list": ini,
        "source_texts": source_texts,
        "source_digests": source_digests,
        "source_bytes": source_bytes,
        "utf8": bool(use_utf8),
        "charset": enc,
        "charset_force": charset,
        "debug_charset": "utf-8" if use_utf8 else "cp932",
        "debug_outputs": bool(a.debug),
        "lzss_mode": (not a.no_angou),
        "exe_angou_mode": (not a.no_angou),
        "source_angou_mode": (not a.no_angou),
        "original_source_mode": (not a.no_os and not a.no_angou),
        "easy_link": bool(a.no_lzss),
        "easy_angou_code": C.EASY_ANGOU_CODE,
        "gameexe_dat_angou_code": C.GAMEEXE_DAT_ANGOU_CODE,
        "source_angou": C.SOURCE_ANGOU,
        "defined_names": set(),
        "stats": stats,
    }
    angou_content = None
    angou_path = ctx["angou_path"]
    if (not a.no_angou) and angou_path:
        try:
            angou_content = first_line_text(
                read_text_auto(
                    angou_path,
                    force_charset=charset,
                    allow_invalid=a.allow_invalid,
                )
            )
        except (OSError, UnicodeError) as exc:
            sys.stderr.write(f"{prog}: error: {angou_path}: {exc}\n")
            return 1
    if angou_content and not angou_first_line(angou_content):
        sys.stderr.write(
            f"{prog}: warning: ignoring {angou_path}: first line encodes to fewer than 8 CP932 bytes\n"
        )
        angou_content = None
    ctx["exe_angou_str"] = angou_content or ""
    stats["angou_content"] = angou_content
    cache_lock = None
    if a.tmp_dir:
        try:
            cache_lock = _CompileCacheLock(tmp)
        except (OSError, RuntimeError) as exc:
            sys.stderr.write(str(exc) + "\n")
            return 1
    native_rc = None
    if is_native_available() and not _runtime._LEGACY_COMPILE:
        try:
            native_rc = _try_native_compile(
                _native_compile_config(
                    args=a,
                    ctx=ctx,
                    input_dir=inp,
                    output_dir=out,
                    scene_pck=scene_pck,
                    tmp_dir=tmp,
                    ss=ss,
                    enc=enc,
                    charset_force=charset,
                    test_shuffle=test_shuffle,
                    force_serial_compile=force_serial_compile,
                    angou_content=angou_content,
                ),
                ctx,
                tmp=tmp,
                tmp_auto=tmp_auto,
                debug=bool(a.debug),
            )
        except Exception:
            if cache_lock is not None:
                cache_lock.close()
            raise
    if native_rc is not None:
        if cache_lock is not None:
            cache_lock.close()
        return native_rc
    ok = False
    test_shuffle_failed = False
    compile_stats = {
        "parallel": False,
        "scene_macro_counts": empty_macro_stat_counts(),
        "global_macro_usage_delta": {},
        "source_stats": empty_source_stat_counts(),
    }
    stage = "GEI"
    try:
        t = time.time()
        if write_gameexe_dat(ctx) is None:
            sys.stderr.write(
                f"{prog}: warning: {ctx.get('gameexe_ini') or 'Gameexe.ini'} not found; "
                "skipped Gameexe.dat\n"
            )
        record_stage_time(ctx, "GEI", time.time() - t)
        if not a.gei:
            stage = "compile cache"
            compile_list, digest_path, pending_digests, full_compile = (
                _compile_cache_state(
                    tmp_dir=tmp,
                    enc=enc,
                    charset=charset,
                    ss=ss,
                    source_digests=source_digests,
                    incremental=bool(a.tmp_dir),
                    allow_invalid=a.allow_invalid,
                )
            )
            if a.tmp_dir:
                try:
                    bs_dir = resolve_read_path(os.path.join(tmp, "bs"), kind="dir")
                except (FileNotFoundError, NotADirectoryError):
                    bs_dir = ""
                if full_compile and bs_dir:
                    _, entries = read_directory(bs_dir)
                    for entry in entries:
                        fn = entry.name
                        if str(fn).lower().endswith(".lzss"):
                            os.remove(os.path.join(bs_dir, fn))
                elif bs_dir:
                    for p in compile_list:
                        nm = os.path.splitext(os.path.basename(p))[0]
                        try:
                            lp = resolve_read_path(
                                os.path.join(bs_dir, nm + ".lzss"), kind="file"
                            )
                        except (FileNotFoundError, NotADirectoryError):
                            continue
                        os.remove(lp)
            if a.dat_repack:
                stage = "dat-repack"
                bs_dir = os.path.join(tmp, "bs")
                os.makedirs(bs_dir, exist_ok=True)
                dats = []
                _, entries = read_directory(inp)
                for entry in sorted(entries, key=lambda item: ascii_lower(item.name)):
                    f = entry.name
                    if not str(f).lower().endswith(".dat"):
                        continue
                    fp = os.path.join(inp, f)
                    if not entry.is_file():
                        continue
                    b = read_bytes(fp)
                    if looks_like_siglus_dat(b):
                        write_bytes(os.path.join(bs_dir, f), b)
                        dats.append(fp)
                if not dats:
                    raise RuntimeError("--dat-repack: no scene .dat found")
                ctx["scn_list"] = [os.path.basename(x) for x in dats]
                compile_list = []
            full_compile_stats = (
                (not a.dat_repack)
                and not a.tmp_dir
                and (not test_shuffle)
                and bool(ss)
                and len(compile_list) == len(ss)
            )
            stats["inc_files"] = len(inc)
            stats["scene_files"] = len(ss)
            stats["compiled_scene_files"] = len(compile_list)
            stats["full_compile_stats"] = full_compile_stats
            if compile_list:
                stage = "compile"
                if test_shuffle:
                    bs_dir = os.path.join(tmp, "bs")
                    os.makedirs(bs_dir, exist_ok=True)
                    if ctx.get("ia_data") is None:
                        ctx["ia_data"] = build_ia_data(ctx)
                    first_ss = compile_list[0]
                    first_nm = os.path.splitext(os.path.basename(first_ss))[0]
                    exp_first = os.path.join(test_dir, first_nm + ".dat")
                    try:
                        exp_first = resolve_read_path(exp_first, kind="file")
                    except (FileNotFoundError, NotADirectoryError):
                        raise FileNotFoundError(f"expected dat not found: {exp_first}")
                    set_shuffle_seed(0)
                    compile_one(ctx, first_ss)
                    my_first = os.path.join(bs_dir, first_nm + ".dat")
                    try:
                        my_first = resolve_read_path(my_first, kind="file")
                    except (FileNotFoundError, NotADirectoryError):
                        raise FileNotFoundError(f"generated dat not found: {my_first}")
                    from collections import Counter

                    pool_my = Counter(_read_scn_dat_str_pool(my_first))
                    pool_off = Counter(_read_scn_dat_str_pool(exp_first))
                    if pool_my != pool_off:
                        sys.stderr.write(
                            f"{test_shuffle_prefix} pool mismatch: not the same string pool -> skip brute force\n"
                        )
                        only_my = list((pool_my - pool_off).elements())[:8]
                        only_off = list((pool_off - pool_my).elements())[:8]
                        if only_my:
                            sys.stderr.write("  only-in-my (sample):\n")
                            for s0 in only_my:
                                sys.stderr.write("    " + repr(s0) + "\n")
                        if only_off:
                            sys.stderr.write("  only-in-expected (sample):\n")
                            for s0 in only_off:
                                sys.stderr.write("    " + repr(s0) + "\n")
                        return 1
                    targets = []
                    for ss_path in compile_list:
                        nm = os.path.splitext(os.path.basename(ss_path))[0]
                        exp_dat = os.path.join(test_dir, nm + ".dat")
                        try:
                            exp_dat = resolve_read_path(exp_dat, kind="file")
                        except (FileNotFoundError, NotADirectoryError):
                            raise FileNotFoundError(
                                f"expected dat not found: {exp_dat}"
                            )
                        targets.append(_read_scn_dat(exp_dat)[2])
                    seed0 = int(test_seed0) & 0xFFFFFFFF
                    if is_native_available():
                        sys.stderr.write(f"{test_shuffle_prefix} Accelerated by Rust\n")
                    sys.stderr.write(
                        f"{test_shuffle_prefix} parallel scan starting at seed={seed0}\n"
                    )
                    from .parallel import find_shuffle_seed_parallel

                    sys.stderr.flush()
                    seed = find_shuffle_seed_parallel(targets[0], seed0)
                    if seed is None:
                        sys.stderr.write(
                            f"{test_shuffle_prefix} no seed found in u32\n"
                        )
                        sys.stderr.flush()
                        return 1
                    sys.stderr.write(
                        f"{test_shuffle_prefix} using seed={seed} (matched first script)\n"
                    )
                    sys.stderr.flush()
                    set_shuffle_seed(seed)
                    all_ok = True
                    seed_rows = []
                    for i, ss_path in enumerate(compile_list):
                        initial_seed = get_shuffle_seed()
                        compile_one(ctx, ss_path)
                        final_seed = get_shuffle_seed()
                        nm = os.path.splitext(os.path.basename(ss_path))[0]
                        my_dat = os.path.join(bs_dir, nm + ".dat")
                        try:
                            my_dat = resolve_read_path(my_dat, kind="file")
                        except (FileNotFoundError, NotADirectoryError):
                            raise FileNotFoundError(
                                f"generated dat not found: {my_dat}"
                            )
                        try:
                            my_idx = _read_scn_dat(my_dat)[2]
                        except Exception:
                            my_idx = None
                        if my_idx != targets[i]:
                            all_ok = False
                            sys.stderr.write(
                                f"{test_shuffle_prefix} index mismatch: {os.path.basename(ss_path)}\n"
                            )
                        seed_rows.append(
                            {
                                "object": os.path.basename(ss_path),
                                "initial_seed": initial_seed,
                                "final_seed": final_seed,
                                "matched": my_idx == targets[i],
                            }
                        )
                    if test_shuffle_csv_path:
                        _write_test_shuffle_csv(test_shuffle_csv_path, seed_rows)
                        sys.stderr.write(
                            f"{test_shuffle_prefix} csv: {test_shuffle_csv_path}\n"
                        )
                    if not all_ok:
                        test_shuffle_failed = True
                        sys.stderr.write(
                            f"{test_shuffle_prefix} ERROR: seed matched first script but mismatch found in later scripts; output will be built with a failure status\n"
                        )
                        sys.stderr.flush()
                else:
                    compile_stats = compile_all(
                        ctx,
                        compile_list,
                        max_workers=a.max_workers,
                        parallel=(not force_serial_compile),
                    )
            if full_compile_stats:
                stage = "statistics"
                stats["macro_counts"] = _collect_macro_stats(ctx, compile_stats)
                stats["source_stats"] = _finalize_source_stats(ctx, compile_stats)
                bs_dir = os.path.join(tmp, "bs")
                (
                    stats["read_flags"],
                    stats["read_flags_scenes"],
                    stats["top5_read_flags_scenes"],
                ) = _collect_read_flag_stats(bs_dir, ss)
            else:
                stats["macro_counts"] = None
                stats["source_stats"] = None
                stats["read_flags"] = None
                stats["read_flags_scenes"] = None
                stats["top5_read_flags_scenes"] = None
            stage = "link"
            link_pack(ctx)
            if pending_digests is not None:
                stage = "compile cache"
                _write_digest_cache(digest_path, pending_digests)
        ok = not test_shuffle_failed
    except Exception as exc:
        sys.stderr.write(
            f"{prog}: error: {stage} ({inp}): {type(exc).__name__}: {exc}\n"
        )
        ok = False
    finally:
        _print_summary(ctx, ok=ok)
        if cache_lock is not None:
            cache_lock.close()
        if ok and (not a.debug) and tmp and tmp_auto:
            shutil.rmtree(tmp, ignore_errors=True)
    return 0 if ok else 1
